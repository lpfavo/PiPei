from django.urls import path
from.import views

urlpatterns=[
    path('index/',views.index_page,name='index'),
    # path('smoke/<str:studentID>',views.getSmoke),
    # path('aircondition/<str:studentID>',views.getAircondition),
    # path('tvShow/<str:studentID>',views.getTVShow),
    # path('novel/<str:studentID>',views.getNovel),
    # path('innerSensitivity/<str:studentID>',views.getInnerSensitivity),
    # path('studentsProvince/<str:studentID>',views.getStudentsProvince),
    # path('sleepTime/<str:studentID>',views.getSleepTime),
    # path('sports/<str:studentID>',views.getSports),
    path('infomation/',views.showInfo_page),
    path('test/',views.test_page,name="test_page,"),
    path('login/',views.getbasicInfo,name="getbasicInfo"),
]
