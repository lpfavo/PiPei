from django.db import models
from django.contrib.auth.models import User


# Create your models here.
class School(models.Model):
    '''
    学校信息
    '''
    school = models.CharField(db_column="学校", max_length=20, null= False, primary_key=True)
    schoolProvince = models.CharField(db_column="学校省份", max_length=20, null= True,)
    remark = models.TextField(db_column="备注", null=True)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    def getSchoolName(self):
        return self.school

    def getSchoolProvince(self):
        return self.schoolProvince

    def getRemark(self):
        return self.remark

    def getAddTime(self):
        return self.addTime


# 通过views函数进行修改，每增加一个或删除一个时，获取已有数据，修改后专业的性别人数，再更新
class Major(models.Model):
    '''
    学校专业信息
    '''
    school = models.ForeignKey(School, null= True,on_delete=models.CASCADE, db_column="学校")
    major = models.CharField(db_column="专业", max_length=20, null= False, blank=False,primary_key=True)
    maleNumber = models.IntegerField(db_column="男生人数", default=0)
    femaleNumber = models.IntegerField(db_column="女生人数", default=0)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getMajor(self):
    #     return self.major
    #
    # def getMaleNumber(self):
    #     return self.maleNumber
    #
    # def getFemaleNumber(self):
    #     return self.femaleNumber
    #
    # def getSchool(self):
    #     return self.school
    #
    # def getAddTime(self):
    #     return self.addTime


class SleepTime(models.Model):
    '''
    学生睡眠时间信息
    '''
    #sleepTime = models.SmallIntegerField(db_column="睡觉时间", null= True, blank=False)#
    sleepTime = models.DateTimeField(db_column="睡觉时间", null= False, blank=False,primary_key=True)
    sleepTimeImportantWeight = models.IntegerField(db_column="睡觉时间重要性权重",null= True, blank=False)#1-5
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getSleepTime(self):
    #     return self.sleepTime
    #
    # def getWeight(self):
    #     return self.importantWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class WakeTime(models.Model):
    '''
    学生起床时间信息
    '''
    wakeTime = models.DateTimeField(db_column="起床时间", null= False, blank=False,primary_key=True)
    wakeTimeImportantWeight = models.IntegerField(db_column="起床时间重要性权重", null= True, blank=False)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getWakeTime(self):
    #     return self.wakeTime
    #
    # def getWeight(self):
    #     return self.importantWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class StudentsProvince(models.Model):
    '''
    学生省份信息
    '''
    studentProvince = models.CharField(db_column="学生省份", max_length=20, null= False, blank=False,primary_key=True)
    southNorth = models.BooleanField(db_column="南北方", null= True, blank=False)
    southNorthWeight = models.IntegerField(db_column="南北方权重", null= True, blank=False)#01
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getStudentProvince(self):
    #     return self.studentProvince
    #
    # def getSouthNorth(self):
    #     return self.southNorth
    #
    # def getWeight(self):
    #     return self.southNorthWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class Sports(models.Model):
    '''
    学生运动信息
    '''
    sports = models.IntegerField(db_column="运动", null= False, blank=False,primary_key=True)#0-9
    sportsWeight = models.IntegerField(db_column="运动权重", null= True, blank=False)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getSports(self):
    #     return self.sports
    #
    # def getWeight(self):
    #     return self.sportsWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class InnerSensitivity(models.Model):
    '''
    学生内心敏感度信息
    '''
    sensitivityWeight = models.IntegerField(db_column="敏感度权重", null= False, blank=False,primary_key=True)#0-5
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getWeight(self):
    #     return self.sensitivityWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class Novel(models.Model):
    '''
    学生阅读小说类型信息
    '''
    novelType = models.IntegerField(db_column="小说类型", null= False, blank=False,primary_key=True)#0-11
    novelTypeWeight = models.IntegerField(db_column="小说类型权重", null= True, blank=False)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getType(self):
    #     return self.novelType
    #
    # def getWeight(self):
    #     return self.novelTypeWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class TVShow(models.Model):
    '''
    学生看剧类型信息
    '''
    tvShowType = models.IntegerField(db_column="看剧类型", null= False, blank=False,primary_key=True)#0-
    tvShowTypeWeight = models.IntegerField(db_column="看剧类型权重", null= True, blank=False)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getType(self):
    #     return self.tvShowType
    #
    # def getWeight(self):
    #     return self.tvShowTypeWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class WinterAircondition(models.Model):
    '''
    冬天空调温度信息
    '''
    wintertemperature = models.IntegerField(db_column="温度", null= False, blank=False,primary_key=True)
    wintertemperatureWeight = models.IntegerField(db_column="温度权重", null= True, blank=False)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getTemperature(self):
    #     return self.wintertemperature
    #
    # def getWeight(self):
    #     return self.wintertemperatureWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class SummerAircondition(models.Model):
        '''
        夏天空调温度信息
        '''
        summertemperature = models.IntegerField(db_column="温度", null=False, blank=False,primary_key=True)  # 1-
        summmertemperatureWeight = models.IntegerField(db_column="温度权重", null=True, blank=False)
        addTime = models.DateTimeField(db_column="添加时间", null=True, blank=False)

        # def getTemperature(self):
        #     return self.summertemperature
        #
        # def getWeight(self):
        #     return self.summmertemperatureWeight
        #
        # def getAddTime(self):
        #     return self.addTime


class Smoking(models.Model):
    '''
    学生吸烟信息
    '''
    smoke = models.BooleanField(db_column="吸烟", null= False, blank=False,primary_key=True)#0不吸烟 1吸烟
    smokeWeight = models.IntegerField(db_column="吸烟权重", null= True, blank=False)
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getSmoke(self):
    #     return self.smoke
    #
    # def getWeight(self):
    #     return self.smokeWeight
    #
    # def getAddTime(self):
    #     return self.addTime


class StudentInfomation(models.Model):
    '''
    学生基本信息
    '''
    studentID = models.CharField(db_column="学生学号", max_length=8, primary_key=True, null=False, blank=False)
    user = models.OneToOneField(User, on_delete=models.CASCADE, db_column="用户")
    studentName = models.CharField(db_column="学生姓名", max_length=20, null=True, blank=False)
    sex = models.BooleanField(db_column="性别", null=True, blank=False)  # 男true 女false？
    school = models.CharField(db_column="学校", max_length=20, null=True, blank=False)
    # major = models.CharField(db_column="专业",max_length=20,null=False,blank=False)
    major = models.ForeignKey(Major,null=True,on_delete=models.CASCADE, db_column="学生专业",)
    #studentClass = models.CharField(db_column="学生班级", max_length=20, null=True, blank=False)
    loginPassword = models.CharField(db_column="登录密码", max_length=20, null=True, blank=False)
    sport = models.ForeignKey(Sports, null=True,on_delete=models.CASCADE, db_column="运动")
    studentProvince = models.ForeignKey(StudentsProvince, null= True,on_delete=models.CASCADE, db_column="学生省份")
    #是否新建表
    southNorth=models.BooleanField(db_column="学生所处南北方",null=True,blank=False)
    innersensitivity = models.ForeignKey(InnerSensitivity, null= True,on_delete=models.CASCADE, db_column="内心敏感度")
    novelType = models.ForeignKey(Novel, null= True,on_delete=models.CASCADE, db_column="小说类型")
    tvShowType = models.ForeignKey(TVShow, null= True,on_delete=models.CASCADE, db_column="看剧类型")
    summertemperature = models.ForeignKey(SummerAircondition, null= True, on_delete=models.CASCADE, db_column="夏天空调合适温度")
    wintertemperature = models.ForeignKey(WinterAircondition, null= True, on_delete=models.CASCADE, db_column="冬天空调合适温度")
    sleepTime = models.ForeignKey(SleepTime, null= True,on_delete=models.CASCADE, db_column="睡眠时间")
    wakeTime = models.ForeignKey(WakeTime, null= True,on_delete=models.CASCADE, db_column="起床时间")
    smoke = models.ForeignKey(Smoking, null= True,on_delete=models.CASCADE, db_column="吸烟")
    addTime = models.DateTimeField(db_column="添加时间", null= True, blank=False)

    # def getStudentID(self):
    #     return self.studentID
    #
    # def getStudentName(self):
    #     return self.studentName
    #
    # def getSex(self):
    #     return self.sex
    #
    # def getSchool(self):
    #     return self.school
    #
    # def getMajor(self):
    #     return self.major
    #
    # def getAddTime(self):
    #     return self.addTime