from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class School(models.Model):
    '''
    学校信息
    '''
    school = models.CharField(db_column="学校",max_length=20, null=False,primary_key=True)
    schoolProvince = models.CharField(db_column="学校省份",max_length=20, null=False)
    remark = models.TextField(db_column="备注",null=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getSchoolName(self):
        return self.school

    def getSchoolProvince(self):
        return self.schoolProvince

    def getRemark(self):
        return self.remark

    def getAddTime(self):
        return self.addTime


class StudentInfomation(models.Model):
    '''
    学生基本信息
    '''
    studentID = models.CharField(db_column="学生学号",max_length=8, primary_key=True,null=False,blank=False)
    user = models.OneToOneField(User,on_delete=models.CASCADE,db_column="用户")
    studentName = models.CharField(db_column="学生姓名",max_length=20,null=False,blank=False)
    sex = models.BooleanField(db_column="性别",null=False,blank=False)#男true 女false？
    school = models.CharField(db_column="学校",max_length=20,null=False,blank=False)
    major = models.CharField(db_column="专业",max_length=20,null=False,blank=False)
    studentClass = models.CharField(db_column="学生班级",max_length=20,null=True,blank=False)
    loginPassword = models.CharField(db_column="登录密码",max_length=20,null=False,blank=False)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getStudentName(self):
        return self.studentName

    def getSex(self):
        return self.sex

    def getSchool(self):
        return self.school

    def getMajor(self):
        return self.major

    def getStudentClass(self):
        return self.studentClass

    def getAddTime(self):
        return self.addTime


#通过views函数进行修改，每增加一个或删除一个时，获取已有数据，修改后专业的性别人数，再更新
class Major(models.Model):
    '''
    学校专业信息
    '''
    school = models.ForeignKey(School, on_delete=models.CASCADE,db_column="学校")
    major = models.CharField(db_column="专业",max_length=20,null=False,blank=False)
    # maleNumber = models.IntegerField(null=False,blank=False)
    # femaleNumber = models.IntegerField(null=False,blank=False)
    maleNumber = models.IntegerField(db_column="男生人数",default=0)
    femaleNumber = models.IntegerField(db_column="女生人数",default=0)
    #school = models.ForeignKey(School, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getMajor(self):
        return self.major

    def getMaleNumber(self):
        return self.maleNumber

    def getFemaleNumber(self):
        return self.femaleNumber

    def getSchool(self):
        return self.school

    def getAddTime(self):
        return self.addTime


class SleepTime(models.Model):
    '''
    学生睡眠信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号")
    sleepTime = models.TimeField(db_column="睡觉时间",null=False,blank=False)
    wakeTime = models.TimeField(db_column="起床时间",null=False,blank=False)
    importantWeight = models.IntegerField(db_column="睡眠重要性权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getSleepTime(self):
        return self.sleepTime

    def getWakeTime(self):
        return self.wakeTime

    def getWeight(self):
        return self.importantWeight

    def getAddTime(self):
        return self.addTime


class StudentsProvince(models.Model):
    '''
    学生省份信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号")
    studentProvince = models.CharField(db_column="学生省份",max_length=20,null=False,blank=False)
    southNorth = models.BooleanField(db_column="南北方",null=False,blank=False)
    southNorthWeight = models.IntegerField(db_column="南北方权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getStudentProvince(self):
        return self.studentProvince

    def getSouthNorth(self):
        return self.southNorth

    def getWeight(self):
        return self.southNorthWeight

    def getAddTime(self):
        return self.addTime


class Sports(models.Model):
    '''
    学生运动信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号")
    sports = models.PositiveSmallIntegerField(db_column="运动",null=False,blank=False)
    sportsWeight = models.IntegerField(db_column="运动权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getSports(self):
        return self.sports

    def getWeight(self):
        return self.sportsWeight

    def getAddTime(self):
        return self.addTime


class InnerSensitivity(models.Model):
    '''
    学生内心敏感度信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号")
    sensitivityWeight = models.IntegerField(db_column="敏感度权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getWeight(self):
        return self.sensitivityWeight

    def getAddTime(self):
        return self.addTime


class Novel(models.Model):
    '''
    学生阅读小说类型信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号")
    novelType = models.PositiveSmallIntegerField(db_column="小说类型",null=False,blank=False)
    novelTypeWeight = models.IntegerField(db_column="小说类型权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getType(self):
        return self.novelType

    def getWeight(self):
        return self.novelTypeWeight

    def getAddTime(self):
        return self.addTime


class TVShow(models.Model):
    '''
    学生看剧类型信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号")
    tvShowType = models.PositiveSmallIntegerField(db_column="看剧类型",null=False,blank=False)
    tvShowTypeWeight = models.IntegerField(db_column="看剧类型权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getType(self):
        return self.tvShowType

    def getWeight(self):
        return self.tvShowTypeWeight

    def getAddTime(self):
        return self.addTime


class Aircondition(models.Model):
    '''
    空调温度信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号")
    temperature = models.PositiveSmallIntegerField(db_column="温度",null=False,blank=False)
    temperatureWeight = models.IntegerField(db_column="温度权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getTemperature(self):
        return self.temperature

    def getWeight(self):
        return self.temperatureWeight

    def getAddTime(self):
        return self.addTime


class Smoking(models.Model):
    '''
    学生吸烟信息
    '''
    studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,db_column="学生学号",)
    smoke = models.BooleanField(db_column="吸烟",null=False,blank=False)
    smokeWeight = models.IntegerField(db_column="吸烟权重",null=False,blank=False)
    #studentID = models.ForeignKey(StudentInfomation, on_delete=models.CASCADE,primary_key=True)
    addTime = models.DateTimeField(db_column="添加时间",null=False,blank=False)

    def getStudentID(self):
        return self.studentID

    def getSmoke(self):
        return self.smoke

    def getWeight(self):
        return self.smokeWeight

    def getAddTime(self):
        return self.addTime