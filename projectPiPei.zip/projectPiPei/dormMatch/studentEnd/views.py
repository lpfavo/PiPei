from django.shortcuts import render
from . import models
from django.contrib import auth
from django.contrib.auth.decorators import login_required
import datetime


# Create your views here.
# @login_required(login_url='index')
def index_page(request):
    return render(request, 'studentEnd/index.html')


# @login_required(login_url='index')
def test_page(request):
    return render(request, 'studentEnd/test.html')


# @login_required(login_url='index')
def getbasicInfo(request):
    name = request.POST.get('name')
    school = request.POST.get('school')
    studentID = request.POST.get('studentID')
    # right = models.StudentInfomation.objects.filter(studentName__exact=name,school__exact=school,studentID__exact=studentID)
    # if right!=[]:
    #     return render(request, 'studentEnd/info_page.html')
    # else:
    #     return render(request, 'studentEnd/index.html',{'errmsg': '用户不存在'})
    user = auth.authenticate(username=name, password=studentID)
    if user is not None and user.is_active:
        auth.login(request, user)
        return render(request, 'studentEnd/info_page.html')
    else:
        return render(request, 'studentEnd/index.html', {'errmsg': '用户不存在'})


# @login_required(login_url='index')
def showInfo_page(request):
    return render(request, 'studentEnd/info_page.html')


# @login_required(login_url='index')
def stuInfo(request):
    school = request.POST.get('school')
    name = request.POST.get('name')
    sex = request.POST.get('sex')
    studentID = request.POST.get('studentID')
    major = request.POST.get('major')
    addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.StudentInfomation.objects.create(school=school,studentName=name,sex=sex,studentID=studentID,major=major,addtime=addtime,loginPassword=studentID)
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.school = school
    student.studentName = name
    student.sex = sex
    student.major = major
    student.addTime = addtime
    student.save()

    majorModify = models.Major.objects.get(school=school, major=major)
    if sex == True:
        majorModify.maleNumber = majorModify.getMaleNumber() + 1
    else:
        majorModify.femaleNumber = majorModify.getFemaleNumber() + 1
    majorModify.save()


# @login_required(login_url='index')
def getSleepTime(request, studentID):
    sleepTime = request.POST.get('sleepTime')
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.sleepTime = sleepTime
    student.save()


# importantWeight = request.POST.get('importantWeight')
# addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
# models.SleepTime.objects.create(sleepTime=sleepTime, wakeTime=wakeTime, importantWeight=importantWeight,studentID=studentID,addTime=addtime)


def getWakeTime(request, studentID):
    wakeTime = request.POST.get('wakeTime')
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.wakeTime = wakeTime
    student.save()


# importantWeight = request.POST.get('importantWeight')
# addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
# models.SleepTime.objects.create(sleepTime=sleepTime, wakeTime=wakeTime, importantWeight=importantWeight,studentID=studentID,addTime=addtime)


# @login_required(login_url='index')
def getStudentsProvince(request, studentID):
    studentProvince = request.POST.get('studentProvince')
    southNorth = request.POST.get('southNorth')
    # southNorthWeight = request.POST.get('southNorthWeight')
    # innerSensitivity = request.POST.get('innerSensitivity')

    # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.SleepTime.objects.create(studentProvince=studentProvince, southNorth=southNorth,southNorthWeight=southNorthWeight, innerSensitivity=innerSensitivity,studentID=studentID,addTime=addtime)
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.studentProvince=studentProvince
    # student.innerSensitivity=innerSensitivity
    student.save()


# @login_required(login_url='index')
def getSports(request, studentID):
    sports = request.POST.get('sports')
    # sportsWeight = request.POST.get('sportsWeight')
    # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.Sports.objects.create(sports=sports, sportsWeight=sportsWeight, studentID=studentID,addTime=addtime)
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.sports = sports
    student.save()


# @login_required(login_url='index')
def getInnerSensitivity(request, studentID):
    innerSensitivity = request.POST.get('innerSensitivity')
    # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.InnerSensitivity.objects.create(innerSensitivity=innerSensitivity,studentID=studentID,addTime=addtime)
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.innerSensitivity = innerSensitivity
    student.save()


# @login_required(login_url='index')
def getNovel(request, studentID):
    novelType = request.POST.get('novelType')
    # novelTypeWeight = request.POST.get('novelTypeWeight')
    # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.Novel.objects.create(novelType=novelType, novelTypeWeight=novelTypeWeight, studentID=studentID,addTime=addtime)
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.novelType = novelType
    student.save()


# @login_required(login_url='index')
def getTVShow(request, studentID):
    tvShowType = request.POST.get('tvType')
    # tvShowTypeWeight = request.POST.get('tvTypeWeight')
    # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.TVShow.objects.create(tvShowType=tvShowType, tvShowTypeWeight=tvShowTypeWeight, studentID=studentID,addTime=addtime)
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.tvShowType = tvShowType
    student.save()


# @login_required(login_url='index')
def getAircondition(request, studentID):
    student = models.StudentInfomation.objects.get(pk=studentID)
    summertemperature = request.POST.get('summertemperature')
    wintertemperature = request.POST.get('wintertemperature')
    student.summertemperature = summertemperature
    student.wintertemperature = wintertemperature
    # temperatureWeight = request.POST.get('temperatureWeight')
    # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.Aircondition.objects.create(temperature=temperature, temperatureWeight=temperatureWeight,studentID=studentID,addTime=addtime)

    student.save()


# @login_required(login_url='index')
def getSmoking(request, studentID):
    smoke = request.POST.get('smoke')
    # smokeWeight =request.POST.get('smoke')
    # addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    # models.Smoking.objects.create(smoke=smoke,smokeWeight=smokeWeight,studentID=studentID,addTime=addtime)
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.smoke = smoke
    student.save()


# @login_required(login_url='index')
def getInfomation(request):
    # 学生基本信息 密码与学号已知  姓名专业可能也已知
    school = request.POST.get('school')
    studentName = request.POST.get('name')
    sex = request.POST.get('sex')
    studentID = request.POST.get('studentID')
    major = request.POST.get('major')
    addtime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    student = models.StudentInfomation.objects.get(pk=studentID)
    student.school = school
    student.studentName = studentName
    student.sex = sex
    student.major = major
    student.addTime = addtime

    majorModify = models.Major.objects.get(school=school, major=major)
    if sex:
        majorModify.maleNumber = majorModify.getMaleNumber() + 1
    else:
        majorModify.femaleNumber = majorModify.getFemaleNumber() + 1
    majorModify.save()

    # 学生省份南北方信息及内心敏感度
    studentProvince = request.POST.get('studentProvince')
    southNorth = request.POST.get('southNorth')
    innerSensitivity = request.POST.get('innerSensitivity')
    student.southNorth=southNorth
    student.studentProvince = studentProvince
    student.innerSensitivity = innerSensitivity


    # 学生睡眠信息
    sleepTime = request.POST.get('sleepTime')
    wakeTime = request.POST.get('wakeTime')
    student.sleepTime = sleepTime
    student.wakeTime = wakeTime

    # 学生运动信息
    sports = request.POST.get('sports')
    student.sports = sports

    # 学生喜爱阅读的小说类型
    novelType = request.POST.get('novelType')
    student.novelType = novelType

    # 学生喜欢观看的电视剧类型
    tvShowType = request.POST.get('tvType')
    student.tvShowType = tvShowType

    # 学生认为空调的合适温度
    summertemperature = request.POST.get('summertemperature')
    wintertemperature = request.POST.get('wintertemperature')
    student.summertemperature = summertemperature
    student.wintertemperature = wintertemperature

    # 学生吸烟信息
    smoke = request.POST.get('smoke')
    student.smoke = smoke
    student.save()